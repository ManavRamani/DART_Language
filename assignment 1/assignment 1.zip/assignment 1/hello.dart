// Write a Dart program to Print Hello Dart :

void main() {
  print("Hello Dart");
}
