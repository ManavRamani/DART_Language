// Write a Dart program to perform addition of two different numbers :

void main() {
  int num1 = 10, num2 = 20;
  print(num1 + num2);
}
