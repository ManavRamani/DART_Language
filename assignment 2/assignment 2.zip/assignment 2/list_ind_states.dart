void main() {
  List l1 = [
    "Jammu and Kashmir",
    "Himachal Pradesh",
    "Punjab",
    "Uttarakhand",
    "Haryana",
    "Uttar Pradesh",
    "Rajasthan",
    "Bihar",
    "West Bengal",
    "Jharkhand",
    "Sikkim",
    "Arunachal Pradesh",
    "Assam",
    "Odisha",
    "Karnataka",
    "Goa",
    "Tamil Nadu",
    "Mizoram",
    "Chhattisgarh",
    "Madhya Pradesh",
    "Maharashtra",
    "Telangana",
    "Andhra Pradesh",
    "Gujarat",
    "Kerala",
    "Meghalaya",
    "Manipur",
    "Nagaland",
    "Tripura"
  ];

  for (int i = 0; i < 29; i++) {
    print("${i + 1} - ${l1[i]}");
  }
}
